ValidaFácil - Mercantil Novinho
Projeto Android pronto para compilar no GitHub Actions.

Passos rápidos:
1. Crie um repositório no GitHub.
2. Faça upload dos arquivos deste ZIP (extrair e enviar os arquivos, não o ZIP).
3. Na aba Actions, execute 'Android - Build APK'.
4. Baixe o artifact 'app-release' quando o workflow terminar.
