package com.mercantilnovinho.validafacil.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val category: String,
    val name: String,
    val brand: String,
    val flavor: String?,
    val weight: String?,
    val quantity: Int,
    val expiryDateIso: String
)
