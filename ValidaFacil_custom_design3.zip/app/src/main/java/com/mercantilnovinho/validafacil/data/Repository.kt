package com.mercantilnovinho.validafacil.data

class Repository(private val dao: ProductDao) {
    fun getAll() = dao.getAll()
    suspend fun insert(p: Product) = dao.insert(p)
    suspend fun delete(p: Product) = dao.delete(p)
    suspend fun getAllList() = dao.getAllList()
}
