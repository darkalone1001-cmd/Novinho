package com.mercantilnovinho.validafacil.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.core.app.NotificationManagerCompat
import androidx.work.Data

class NotificationWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val title = inputData.getString("title") ?: "Validade"
        val body = inputData.getString("body") ?: ""
        val notificationId = inputData.getInt("notificationId", System.currentTimeMillis().toInt())

        val notif = NotificationUtils.build(applicationContext, title, body)
        NotificationManagerCompat.from(applicationContext).notify(notificationId, notif)
        return Result.success()
    }

    companion object {
        fun buildData(title:String, body:String, id:Int): Data {
            return Data.Builder()
                .putString("title", title)
                .putString("body", body)
                .putInt("notificationId", id)
                .build()
        }
    }
}
