package com.mercantilnovinho.validafacil.notifications

import android.content.Context
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Data
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.ZoneId
import java.util.concurrent.TimeUnit
import com.mercantilnovinho.validafacil.data.Product
import androidx.work.ExistingWorkPolicy

object Scheduler {
    private val fmt = DateTimeFormatter.ISO_LOCAL_DATE

    private fun millisUntil(targetDate: LocalDate): Long {
        val now = LocalDate.now()
        val startOfTarget = targetDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val startOfNow = now.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        return startOfTarget - startOfNow
    }

    fun scheduleNotifications(context: Context, product: Product) {
        NotificationUtils.createChannel(context)
        val expiry = LocalDate.parse(product.expiryDateIso, fmt)
        val productName = "${product.name} (${product.brand})"
        listOf(7,3,0).forEach { daysBefore ->
            val fireDate = expiry.minusDays(daysBefore.toLong())
            val delayMillis = millisUntil(fireDate)
            if (delayMillis < 0) return@forEach
            val message = when(daysBefore){7->"Vence em 7 dias";3->"Vence em 3 dias";0->"Vence hoje";else->"Vencimento próximo"}
            val data = NotificationWorker.buildData(productName, "$message: ${product.name}", product.id.hashCode()+daysBefore)
            val req = OneTimeWorkRequestBuilder<NotificationWorker>()
                .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
                .setInputData(data)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork("${product.id}-$daysBefore", ExistingWorkPolicy.REPLACE, req)
        }
    }

    fun cancelNotifications(context: Context, productId: String) {
        val wm = WorkManager.getInstance(context)
        listOf(7,3,0).forEach { days ->
            wm.cancelUniqueWork("$productId-$days")
        }
    }
}
