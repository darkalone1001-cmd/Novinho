package com.mercantilnovinho.validafacil.ui

import androidx.compose.runtime.*
import androidx.compose.material.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import com.mercantilnovinho.validafacil.data.Product
import com.mercantilnovinho.validafacil.viewmodel.ProductViewModel

@Composable
fun AddEditProductScreen(vm: ProductViewModel, onDone: ()->Unit) {
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var flavor by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    var date by remember { mutableStateOf(LocalDate.now().plusDays(7).format(DateTimeFormatter.ISO_LOCAL_DATE)) }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome do produto") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Marca") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Categoria") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = flavor, onValueChange = { flavor = it }, label = { Text("Sabor/Variedade") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = weight, onValueChange = { weight = it }, label = { Text("Gramatura/Tamanho") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = quantity, onValueChange = { quantity = it }, label = { Text("Quantidade") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Data de validade (YYYY-MM-DD)") })
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            val p = Product(category=category, name=name, brand=brand, flavor=if(flavor.isBlank()) null else flavor, weight=if(weight.isBlank()) null else weight, quantity=quantity.toIntOrNull() ?: 1, expiryDateIso=date)
            vm.insert(p)
            onDone()
        }) { Text("Salvar") }
    }
}
