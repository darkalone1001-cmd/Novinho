package com.mercantilnovinho.validafacil.ui

import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Yellow = Color(0xFFFFD600)
private val Red = Color(0xFFD32F2F)

@Composable
fun MainApp() {
    val colors = lightColors(
        primary = Yellow,
        primaryVariant = Red,
        secondary = Red,
        onPrimary = Color.Black
    )
    MaterialTheme(colors = colors) {
        Surface {
            ProductListScreen()
        }
    }
}
