package com.mercantilnovinho.validafacil.ui

import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mercantilnovinho.validafacil.data.Product
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun ProductListScreen() {
    val fmt = DateTimeFormatter.ISO_LOCAL_DATE
    val sample = listOf(
        Product(id="1", category="Laticínios", name="Leite", brand="Mercantil Novinho", flavor=null, weight="1L", quantity=8, expiryDateIso=LocalDate.now().plusDays(6).format(fmt))
    )

    Scaffold(
        topBar = { TopAppBar(title = { Text("ValidaFácil - Mercantil Novinho") }) },
        floatingActionButton = { FloatingActionButton(onClick = {}) { Text("+") } }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(16.dp)) {
            items(sample) { p ->
                ProductRow(p, onDelete = {})
            }
        }
    }
}

@Composable
fun ProductRow(p: Product, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("${p.name} — ${p.brand}")
                Text("${p.category} • ${p.flavor ?: ""} • ${p.weight ?: ""}")
                Text("Validade: ${p.expiryDateIso}  •  Qtd: ${p.quantity}")
            }
            Column {
                Button(onClick = onDelete) { Text("Remover") }
            }
        }
    }
}
