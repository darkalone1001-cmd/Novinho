package com.mercantilnovinho.validafacil.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mercantilnovinho.validafacil.data.AppDatabase
import com.mercantilnovinho.validafacil.data.Product
import com.mercantilnovinho.validafacil.data.Repository
import com.mercantilnovinho.validafacil.notifications.Scheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProductViewModel(application: Application): AndroidViewModel(application) {
    private val repo: Repository
    val productsFlow

    init {
        val db = AppDatabase.getInstance(application)
        repo = Repository(db.productDao())
        productsFlow = repo.getAll()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    fun insert(product: Product) {
        viewModelScope.launch {
            repo.insert(product)
            Scheduler.scheduleNotifications(getApplication(), product)
        }
    }

    fun delete(product: Product) {
        viewModelScope.launch {
            repo.delete(product)
            Scheduler.cancelNotifications(getApplication(), product.id)
        }
    }
}
